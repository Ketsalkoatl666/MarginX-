MarginX v4 — NO ZERO / RELATIVE-ONLY MANUAL POSITIONING

REPLACES: tools/marginx_control.py and tools/marginx_ui.py
UNCHANGED: tools/motorlib.py, tools/marginxGUI.py, config/shift_state.json

Workflow:
Login -> Manual Positioning (jog freely under operator supervision)
-> Continue (confirm physical clearance; no Set Start Position/zero button)
-> Cup + Cover -> scan 1/3, 1/2, 2/3 of configurable RELATIVE span
-> RETURN the exact commanded displacement to the pre-scan position -> Finished.

No JSON coordinate validation, home, or automatic calibration. The existing
shift_state.json is not read or modified by this controller.

CRITICAL SAFETY LIMITATION:
No zero sensor, limit switch, encoder, or absolute position means software CANNOT
know the real travel limits. The operator MUST physically check every jog and
ensure safe leftward clearance for the configured scan span.
SCAN_SPAN_STEPS=6000 is an EXAMPLE ONLY (30 mm at 200 steps/mm).
The maximum actual leftward displacement is 2/3 of that span (20 mm).
Set this to your physically verified safe design value before starting a scan.
A lost step, interrupted scan, emergency stop, power interruption or manual
mechanical movement makes relative-position return unreliable; do NOT restart
or automatically return following a fault. Hardware safety stop is independent.

INSTALL:
1. Exit MarginX and turn off the 24 V motor power while replacing files.
2. cd ~/marginx
3. mkdir -p backup_before_nozero_v4
4. cp tools/marginx_control.py tools/marginx_ui.py config/shift_state.json backup_before_nozero_v4/
5. unzip -o MarginX_no_zero_v4.zip -d tools/
6. .venv/bin/python3 -m py_compile tools/marginx_control.py tools/marginx_ui.py
7. Launch: .venv/bin/python3 tools/marginxGUI.py
8. Test UI only with motors unpowered; NEVER press Jog or Start Scan unpowered.
9. Verify motor path & emergency system. Then powered 1mm jog with clearance.

The UI stays fullscreen and retains original Tkinter visual style and keyboard.
Hardware pin mappings are unchanged: Cup GPIO5; Cover GPIO6; LED GPIO26;
Shift STEP/DIR GPIO17/27; Rotation STEP/DIR GPIO23/24.
